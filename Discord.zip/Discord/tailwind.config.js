/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["*"],
  theme: {
    extend: {
      fontFamily: {
        Whitney: "Whitney",
        Ginto: "Ginto",
        ggsans: "ggsans",
        boldest: "'Black Ops One', cursive",
        p: "'Archivo', sans-serif;",
      },
    },
    plugins: [],
  },
};
