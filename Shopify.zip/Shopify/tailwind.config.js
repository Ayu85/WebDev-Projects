/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["*"],
  theme: {
    extend: {
      colors: {
        ghee: "#E6BE8A",
        hero:"#c5c5c5",
        btn:"#ffac01",
        graybg:"#d1d1d1",
        
      },
      fontFamily: {
        poppins: "'Poppins', sans-serif;",
        prodfont:"'Montserrat', sans-serif"
      },
    },
    plugins: [],
  },
};
