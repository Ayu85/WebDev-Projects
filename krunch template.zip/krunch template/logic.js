let nav = document.getElementById('navbar')
window.addEventListener('scroll', function () {
    if (pageYOffset > 700) {
        nav.classList.add('navclass')
    }
    else {
        nav.classList.remove('navclass')
    }
})

let box1 = document.getElementById('b1_info')
let box2 = document.getElementById('b2_info')
let box3 = document.getElementById('b3_info')
let box4 = document.getElementById('b4_info')
let box5 = document.getElementById('b5_info')
let box6 = document.getElementById('b6_info')
let box7 = document.getElementById('b7_info')
let box8 = document.getElementById('b8_info')
let b1 = document.getElementById('b1')
let b2 = document.getElementById('b2')
let b3 = document.getElementById('b3')
let b4 = document.getElementById('b4')
let b5 = document.getElementById('b5')
let b6 = document.getElementById('b6')
let b7 = document.getElementById('b7')
let b8 = document.getElementById('b8')

b1.addEventListener('mouseover', function () {
    b1.style.background = `linear-gradient(rgba(77, 140, 240, .8),rgba(77, 140, 100, .8)),url('3d.jpg')`
    b1.style.backgroundSize = 'cover '
    box1.style.visibility = 'visible'
    box1.style.transform = 'translateY(0)'
    box1.style.transition = 'transform .5s ease-in-out'
})
b1.addEventListener('mouseout', () => {
    b1.style.background = `url('3d.jpg')`
    b1.style.backgroundSize = 'cover '
    box1.style.visibility = 'hidden'
    box1.style.transform = 'translateY(50px)'
    box1.style.transition = 'transform .5s ease-in-out'

})
b2.addEventListener('mouseover', function () {
    b2.style.background = `linear-gradient(rgba(77, 140, 240, .8),rgba(77, 140, 100, .8)),url('apps.jpg')`
    b2.style.backgroundSize = 'cover '
    box2.style.visibility = 'visible'
    box2.style.transform = 'translateY(0)'
    box2.style.transition = 'transform .5s ease-in-out'
})
b2.addEventListener('mouseout', () => {
    b2.style.background = `url('apps.jpg')`
    b2.style.backgroundSize = 'cover '
    box2.style.visibility = 'hidden'
    box2.style.transform = 'translateY(50px)'
    box2.style.transition = 'transform .5s ease-in-out'
})
b3.addEventListener('mouseover', function () {
    b3.style.background = `linear-gradient(rgba(77, 140, 240, .8),rgba(77, 140, 100, .8)),url('company_logo.jpg')`
    b3.style.backgroundSize = 'cover '
    box3.style.visibility = 'visible'
    box3.style.transform = 'translateY(0)'
    box3.style.transition = 'transform .5s ease-in-out'
})
b3.addEventListener('mouseout', () => {
    b3.style.background = `url('company_logo.jpg')`
    b3.style.backgroundSize = 'cover '
    box3.style.visibility = 'hidden'
    box3.style.transform = 'translateY(50px)'
    box3.style.transition = 'transform .5s ease-in-out'
})
b4.addEventListener('mouseover', () => {
    b4.style.background = `linear-gradient(rgba(77, 140, 240, .8),rgba(77, 140, 100, .8)),url('graphic_design.webp')`
    b4.style.backgroundSize = 'cover '
    box4.style.visibility = 'visible'
    box4.style.transform = 'translateY(0px)'
    box4.style.transition = 'transform .5s ease-in-out'
})
b4.addEventListener('mouseout', () => {
    b4.style.background = `url('graphic_design.webp')`
    b4.style.backgroundSize = 'cover '
    box4.style.visibility = 'hidden'
    box4.style.transform = 'translateY(50px)'
    box4.style.transition = 'transform .5s ease-in-out'
})

b5.addEventListener('mouseover', () => {
    b5.style.background = `linear-gradient(rgba(77, 140, 240, .8),rgba(77, 140, 100, .8)),url('grapjhic.webp')`
    b5.style.backgroundSize = 'cover '
    box5.style.visibility = 'visible'
    box5.style.transform = 'translateY(0px)'
    box5.style.transition = 'transform .5s ease-in-out'
})
b5.addEventListener('mouseout', () => {
    b5.style.background = `url('grapjhic.webp')`
    b5.style.backgroundSize = 'cover '
    box5.style.visibility = 'hidden'
    box5.style.transform = 'translateY(50px)'
    box5.style.transition = 'transform .5s ease-in-out'
})

b6.addEventListener('mouseover', () => {
    b6.style.background = `linear-gradient(rgba(77, 140, 240, .8),rgba(77, 140, 100, .8)),url('home.avif')`
    b6.style.backgroundSize = 'cover '
    box6.style.visibility = 'visible'
    box6.style.transform = 'translateY(0px)'
    box6.style.transition = 'transform .5s ease-in-out'
})
b6.addEventListener('mouseout', () => {
    b6.style.background = `url('home.avif')`
    b6.style.backgroundSize = 'cover '
    box6.style.visibility = 'hidden'
    box6.style.transform = 'translateY(50px)'
    box6.style.transition = 'transform .5s ease-in-out'
})
b7.addEventListener('mouseover', () => {
    b7.style.background = `linear-gradient(rgba(77, 140, 240, .8),rgba(77, 140, 100, .8)),url('interior.jpg')`
    b7.style.backgroundSize = 'cover '
    box7.style.visibility = 'visible'
    box7.style.transform = 'translateY(0px)'
    box7.style.transition = 'transform .5s ease-in-out'
})
b7.addEventListener('mouseout', () => {
    b7.style.background = `url('interior.jpg')`
    b7.style.backgroundSize = 'cover '
    box7.style.visibility = 'hidden'
    box7.style.transform = 'translateY(50px)'
    box7.style.transition = 'transform .5s ease-in-out'
})
b8.addEventListener('mouseover', () => {
    b8.style.background = `linear-gradient(rgba(77, 140, 240, .8),rgba(77, 140, 100, .8)),url('web.jpg')`
    b8.style.backgroundSize = 'cover '
    box8.style.visibility = 'visible'
    box8.style.transform = 'translateY(0px)'
    box8.style.transition = 'transform .5s ease-in-out'
})
b8.addEventListener('mouseout', () => {
    b8.style.background = `url('web.jpg')`
    b8.style.backgroundSize = 'cover '
    box8.style.visibility = 'hidden'
    box8.style.transform = 'translateY(50px)'
    box8.style.transition = 'transform .5s ease-in-out'
})


// team members logic starts here
let mem1 = document.getElementById('mem1')
let mem2 = document.getElementById('mem2')
let mem_pro = document.getElementsByClassName('mem_profile')

mem1.addEventListener('mouseover', function () {
    for (let i = 0; i < mem_pro.length - 3; i++) {
        mem1.style.background = `linear-gradient(rgba(50, 140, 240, .6),rgba(77, 140, 100, .6)),url('ajay.jpg')`
        mem_pro[i].style.visibility = 'visible'
        mem_pro[i].style.transform = 'translateY(0)'
        mem_pro[i].style.transition = 'transform .5s ease-in-out'
    }
})
mem1.addEventListener('mouseout', function () {
    for (let i = 0; i < mem_pro.length - 3; i++) {
        mem1.style.background = `url('ajay.png')`
        mem1.style.backgroundSize = 'cover'
        mem_pro[i].style.visibility = 'hidden'
        mem_pro[i].style.transform = 'translateY(60px)'
        mem_pro[i].style.transition = 'transform .5s ease-in-out'
    }
})

mem2.addEventListener('mouseover', function () {
    for (let i = 3; i < mem_pro.length; i++) {
        mem2.style.background = `linear-gradient(rgba(50, 140, 240, .7),rgba(77, 140, 100, .7)),url('ayush.jpg')`
        mem2.style.backgroundSize = 'cover'

        mem_pro[i].style.visibility = 'visible'
        mem_pro[i].style.transform = 'translateY(0)'
        mem_pro[i].style.transition = 'transform .5s ease-in-out'
    }
})
mem2.addEventListener('mouseout', function () {
    for (let i = 3; i < mem_pro.length; i++) {
        mem2.style.background = `url('ayush.jpg')`
        mem2.style.backgroundSize = 'cover'
        mem_pro[i].style.visibility = 'hidden'
        mem_pro[i].style.transform = 'translateY(60px)'
        mem_pro[i].style.transition = 'transform .5s ease-in-out'
    }
})